package com.example.mad_expense_tracker;
import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferencesHelper {

    private static final String PREFS_NAME = "ProfilePrefs";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_MONTHLY_SPENDING = "monthly_spending";

    private SharedPreferences sharedPreferences;

    public SharedPreferencesHelper(Context context) {
        sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void saveUserName(String username) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_USERNAME, username);
        editor.apply();
    }

    public String getUserName() {
        return sharedPreferences.getString(KEY_USERNAME, "");
    }

    public void saveMonthlySpending(int monthlySpending) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(KEY_MONTHLY_SPENDING, monthlySpending);
        editor.apply();
    }

    public int getMonthlySpending() {
        return sharedPreferences.getInt(KEY_MONTHLY_SPENDING, 1);
    }
}