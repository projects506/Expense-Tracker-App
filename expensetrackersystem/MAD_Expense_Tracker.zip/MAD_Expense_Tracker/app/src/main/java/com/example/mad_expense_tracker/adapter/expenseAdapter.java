package com.example.mad_expense_tracker.adapter;

import android.content.Context;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.example.mad_expense_tracker.DatabaseHandlerExpense;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mad_expense_tracker.R;
import com.example.mad_expense_tracker.model.expenseModel;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class expenseAdapter extends RecyclerView.Adapter<expenseAdapter.viewholder> {
    private Context context;
    private DatabaseHandlerExpense databaseHandler;
    private List<expenseModel> expenseModelList = new ArrayList<>();
    public expenseAdapter(Context context, List<expenseModel> expenseModelList, DatabaseHandlerExpense databaseHandler) {
        this.context = context;
        this.expenseModelList = expenseModelList;
        this.databaseHandler = databaseHandler;
    }
    public expenseAdapter(Context context, List<expenseModel> incomeModelList) {
        this.context = context;
        this.expenseModelList = expenseModelList;
    }

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.layout_expense_item, parent, false);
        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {
        expenseModel model = expenseModelList.get(position);
        holder.tv_incomeAmount.setText("₹"+model.getAmount());

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(Long.parseLong(model.getDate()));
        String formattedDate = DateFormat.format("dd/MM/yyyy", calendar).toString();

        holder.tv_incomeDate.setText(formattedDate);
        holder.tv_incomeJob.setText(model.getType());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showExpenseDialog(context, model);
            }
        });
    }

    @Override
    public int getItemCount() {
        return expenseModelList.size();
    }

    class viewholder extends RecyclerView.ViewHolder {
        TextView tv_incomeJob, tv_incomeAmount, tv_incomeDate;

        public viewholder(@NonNull View itemView) {
            super(itemView);

            tv_incomeAmount = itemView.findViewById(R.id.tv_expenseAmount);
            tv_incomeJob = itemView.findViewById(R.id.tv_expenseJob);
            tv_incomeDate = itemView.findViewById(R.id.tv_expenseDate);

        }
    }
    public void showExpenseDialog(Context context, expenseModel model) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);

        final View customLayout = LayoutInflater.from(context).inflate(R.layout.expense_add_item, null);
        EditText et_income = customLayout.findViewById(R.id.et_incomeAmount);
        EditText et_type = customLayout.findViewById(R.id.et_incomeType);
        EditText et_note = customLayout.findViewById(R.id.et_incomeNote);

        et_income.setText(model.getAmount());
        et_type.setText(model.getType());
        et_note.setText(model.getNote());

        Button btn_save = customLayout.findViewById(R.id.btn_save);
        Button btn_delete = customLayout.findViewById(R.id.btn_delete);
        btn_delete.setVisibility(View.VISIBLE);


        builder.setView(customLayout);
        AlertDialog alertDialog = builder.create();

        alertDialog.show();



        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = model.getId();
                String amount = et_income.getText().toString();
                String type = et_type.getText().toString();
                String note = et_note.getText().toString();
                long date = System.currentTimeMillis();

                if (amount.isEmpty()) {
                    et_income.setError("Empty amount");
                    return;
                } else if (type.isEmpty()) {
                    et_type.setError("Empty Type");
                    return;
                } else if (note.isEmpty()) {
                    et_note.setError("Empty note");
                    return;
                } else {
                    databaseHandler.update(id, amount, type, note, String.valueOf(date));
                    alertDialog.dismiss();

                }

            }
        });
        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = model.getId();
                databaseHandler.deleteExpense(id);
                alertDialog.dismiss();

            }
        });

    }

}
