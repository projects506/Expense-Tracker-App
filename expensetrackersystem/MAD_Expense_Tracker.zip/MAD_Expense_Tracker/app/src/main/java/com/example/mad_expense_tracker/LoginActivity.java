package com.example.mad_expense_tracker; // Replace with your package name

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
public class LoginActivity extends AppCompatActivity {
    private EditText[] pinBoxes = new EditText[4];
    private Button loginButton;
    private TextView instructionText;
    private SharedPreferences sharedPreferences;

    private static final String PIN_KEY = "user_pin";
    private static final String IS_FIRST_LAUNCH_KEY = "is_first_launch";
    private boolean isSettingUpPin = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login); // Replace with your layout file

        pinBoxes[0] = findViewById(R.id.pin_box1);
        pinBoxes[1] = findViewById(R.id.pin_box2);
        pinBoxes[2] = findViewById(R.id.pin_box3);
        pinBoxes[3] = findViewById(R.id.pin_box4);
        loginButton = findViewById(R.id.login_button);
        instructionText = findViewById(R.id.pin_title);
        sharedPreferences = getSharedPreferences("app_data", MODE_PRIVATE);

        // Check for first launch using the IS_FIRST_LAUNCH_KEY flag
        boolean isFirstLaunch = sharedPreferences.getBoolean(IS_FIRST_LAUNCH_KEY, true);
        if (isFirstLaunch) {
            // First-time setup - Ask user to set PIN
            isSettingUpPin = true;
            instructionText.setText("Set your 4-digit PIN");
            setupInputListeners();
        } else {
            // Not first launch - Ask for PIN to log in
            instructionText.setText("Enter your PIN");
            setupInputListeners();
        }
    }

    private void setupInputListeners() {
        for (EditText pinBox : pinBoxes) {
            pinBox.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (s.length() == 1) { // Move to next box after entering one digit
                        pinBox.clearFocus();
                        int index = Arrays.asList(pinBoxes).indexOf(pinBox);
                        if (index < pinBoxes.length - 1) {
                            pinBoxes[index + 1].requestFocus();
                        } else {
                            // All PIN boxes filled
                            if (isSettingUpPin) {
                                confirmPin(); // Confirm and store PIN
                            } else {
                                attemptLogin(); // Check entered PIN against stored PIN
                            }
                        }
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {}
            });
        }
    }

    private void attemptLogin() {
        String enteredPin = getEnteredPin();
        String storedPin = sharedPreferences.getString(PIN_KEY, null);

        if (enteredPin.equals(storedPin)) {
            // Login successful - Start MainActivity or desired activity
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);

        } else {
            // Incorrect PIN
            Toast.makeText(LoginActivity.this, storedPin, Toast.LENGTH_SHORT).show();
            clearPinBoxes();
        }
    }

    public void clearPinBoxes() {
        for (EditText pinBox : pinBoxes) {
            pinBox.setText("");
        }
        pinBoxes[0].requestFocus();
    }

    private void confirmPin() {
        String enteredPin = getEnteredPin();

        // Store PIN permanently and mark first launch as done
        sharedPreferences.edit()
                .putString(PIN_KEY, enteredPin)
                .putBoolean(IS_FIRST_LAUNCH_KEY, false)
                .apply();

        clearPinBoxes();
        instructionText.setText("PIN set successfully!");
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        // Close LoginActivity
    }

    @Override
    protected void onResume() {
        super.onResume();
        // ... (no changes needed in onResume) ...
    }

    // Helper method to get entered PIN from EditText boxes
    private String getEnteredPin() {
        StringBuilder pinBuilder = new StringBuilder();
        for (EditText pinBox : pinBoxes) {
            pinBuilder.append(pinBox.getText().toString());
        }
        return pinBuilder.toString();
    }
}