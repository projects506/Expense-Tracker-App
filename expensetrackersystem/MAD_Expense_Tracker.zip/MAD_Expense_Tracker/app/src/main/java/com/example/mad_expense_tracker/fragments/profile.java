package com.example.mad_expense_tracker.fragments; // Adjust package name
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.mad_expense_tracker.R;
import com.example.mad_expense_tracker.SharedPreferencesHelper;

public class profile extends Fragment {

    private EditText etUsername, etMonthlySpending;
    private Button btnSaveProfile;
    private SharedPreferencesHelper sharedPreferencesHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.layout_profile, container, false);

        etUsername = view.findViewById(R.id.et_username);
        etMonthlySpending = view.findViewById(R.id.et_monthly_spending);
        btnSaveProfile = view.findViewById(R.id.btn_save_profile);

        sharedPreferencesHelper = new SharedPreferencesHelper(getContext());

        // Load saved data
        String savedUsername = sharedPreferencesHelper.getUserName();
        int savedMonthlySpending = sharedPreferencesHelper.getMonthlySpending();

        etUsername.setText(savedUsername);
        etMonthlySpending.setText(String.valueOf(savedMonthlySpending));

        btnSaveProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveProfileData();
            }
        });

        return view;
    }

    private void saveProfileData() {
        String username = etUsername.getText().toString().trim();
        String monthlySpendingStr = etMonthlySpending.getText().toString().trim();

        if (username.isEmpty()) {
            etUsername.setError("Please enter a username");
            return;
        }

        if (monthlySpendingStr.isEmpty()) {
            etMonthlySpending.setError("Please enter a monthly spending amount");
            return;
        }

        int monthlySpending = Integer.parseInt(monthlySpendingStr);

        sharedPreferencesHelper.saveUserName(username);
        sharedPreferencesHelper.saveMonthlySpending(monthlySpending);

        Toast.makeText(getContext(), "Profile data saved", Toast.LENGTH_SHORT).show();
    }
}